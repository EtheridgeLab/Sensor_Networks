/**
 * @file ThingSpeakPublisher.cpp
 * @copyright 2020 Stroud Water Research Center
 * Part of the EnviroDIY ModularSensors library for Arduino
 * @author Sara Geleskie Damiano <sdamiano@stroudcenter.org>
 *
 * @brief Implements the ThingSpeakPublisher class.
 */

 // Comments from Zeke based on code edits
 // code_ThingSpeakPublisher

 // Hi there! If you're working on this project and you made it here, congrats!
 // It's quite a trek. The way I'm labeling these code sections (ThingSpeakPublisher.h
//  and ThingSpeakPublisher.cpp)
 // files is different from how I labelled the Arduino libraries. Most of the
 // code in this library works just as it needs to for our project. There were
 // a few things I had to change to make the code run properly. I've labeled
 // a few of the things I changed in this script for reference. Ctrl+F for
 // Zgeneral to find them.


#include "InfluxPublisher.h"


// ============================================================================
//  Functions for the EnviroDIY data portal receivers.
// ============================================================================

// Constant values for MQTT publish
// I want to refer to these more than once while ensuring there is only one copy
// in memory

//Zgeneral
//mqttServer was changed from mqtt.thingspeak.com to mqtt3.thingspeak.com
const char* InfluxPublisher::mqttServer     = "tcp://127.0.0.1:1883"; //edited, what goes here
const int   InfluxPublisher::mqttPort       = 1883;
//mqttClientName was changed to mqttClientID
const char* InfluxPublisher::mqttClientID   = INFLUX_CLIENT_ID;
const char* InfluxPublisher::mqttUser       = INFLUX_USER_NAME;
//mqttPass was added for new ThingSpeak
const char* InfluxPublisher::mqttPass       = INFLUX_PASS_WORD;


// Constructors

//Zgeneral
//Username, Password, and ClientID added here
InfluxPublisher::InfluxPublisher() : dataPublisher() {
    // MS_DBG(F("ThingSpeakPublisher object created"));
    _influxUsername   = NULL;  //Zgeneral
    _influxPassword   = NULL;  //Zgeneral
    _influxClientID   = NULL;  //Zgeneral
}

//Zgeneral
//Username, Password, and ClientID added here
InfluxPublisher::InfluxPublisher(Logger& baseLogger, uint8_t sendEveryX,
                                         uint8_t sendOffset)
    : dataPublisher(baseLogger, sendEveryX, sendOffset) {
    // MS_DBG(F("ThingSpeakPublisher object created"));
    _influxUsername   = NULL;  //Zgeneral
    _influxPassword   = NULL;  //Zgeneral
    _influxClientID   = NULL;  //Zgeneral
}

//Zgeneral
//Username, Password, and ClientID added here
InfluxPublisher::InfluxPublisher(Logger& baseLogger, Client* inClient,
                                         uint8_t sendEveryX, uint8_t sendOffset)
    : dataPublisher(baseLogger, inClient, sendEveryX, sendOffset) {
    // MS_DBG(F("ThingSpeakPublisher object created"));
    _influxUsername   = NULL;  //Zgeneral
    _influxPassword   = NULL;  //Zgeneral
    _influxClientID   = NULL;  //Zgeneral
}

//Zgeneral
//Username, Password, and ClientID added here
InfluxPublisher::InfluxPublisher(Logger& baseLogger,
                                         const char* influxUsername,
                                         const char* influxPassword,
                                         const char* influxClientID,
                                         uint8_t sendEveryX, uint8_t sendOffset)
    : dataPublisher(baseLogger, sendEveryX, sendOffset) {
    setUsername(influxUsername);  //Zgeneral
    setPassword(influxPassword);  //Zgeneral
    setClientID(influxClientID);  //Zgeneral
    // MS_DBG(F("ThingSpeakPublisher object created"));
}

// Zgeneral
// Username, Password, and ClientID added here
InfluxPublisher::InfluxPublisher(Logger& baseLogger, Client* inClient,
                                         const char* influxUsername,
                                         const char* influxPassword,
                                         const char* influxClientID,
                                         uint8_t sendEveryX, uint8_t sendOffset)
    : dataPublisher(baseLogger, inClient, sendEveryX, sendOffset) {
    setUsername(influxUsername);
    setPassword(influxPassword);
    setClientID(influxClientID);
    // MS_DBG(F("ThingSpeakPublisher object created"));
}
// Destructor
InfluxPublisher::~InfluxPublisher() {}


// Zgeneral
// Username, Password, and ClientID added here
void InfluxPublisher::setUsername(const char* influxUsername) {
    _influxUsername = influxUsername;
    // MS_DBG(F("Username set!"));
}

void InfluxPublisher::setPassword(const char* influxPassword) {
    _influxPassword = influxPassword;
    // MS_DBG(F("Password set!"));
}

void InfluxPublisher::setClientID(const char* influxClientID) {
    _influxClientID = influxClientID;
    // MS_DBG(F("Client ID set!"));
}


// Original Comment
// Sets all 3 ThingSpeak parameters

// Zgeneral
// Username, Password, and ClientID added here
void InfluxPublisher::setInfluxParams(const char* Username,
                                              const char* Password,
                                              const char* ClientID) {
    setUsername(Username);
    setPassword(Password);
    setClientID(ClientID);

}


// A way to begin with everything already set
void InfluxPublisher::begin(Logger& baseLogger, Client* inClient,
                                const char* influxUsername,
                                const char* influxPassword,
                                const char* influxClientID
                              ) {
    setUsername(influxUsername);
    setPassword(influxPassword);
    setClientID(influxClientID);
    dataPublisher::begin(baseLogger, inClient);
}
void InfluxPublisher::begin(Logger& baseLogger,
                                const char* influxUsername,
                                const char* influxPassword,
                                const char* influxClientID
                              ) {
    setUsername(influxUsername);
    setPassword(influxPassword);
    setClientID(influxClientID);
    dataPublisher::begin(baseLogger);
}


// This sends the data to ThingSpeak
// bool ThingSpeakPublisher::mqttThingSpeak(void)
int16_t InfluxPublisher::publishData(Client* outClient) {
    bool retVal = false;

    uint8_t numChannels = _baseLogger->getArrayVarCount();
    MS_DBG(numChannels, F("fields will be sent to ThingSpeak"));

    // Create a buffer for the portions of the request and response
    char tempBuffer[26] = "";

    char topicBuffer[25] = "hydrossensors/"; //was 42
    strcat(topicBuffer, rand() % 100);
    strcat(topicBuffer, "/publish");
    //MS_DBG(F("Topic ["), strlen(topicBuffer), F("]:"), String(topicBuffer));

    emptyTxBuffer();

    _baseLogger->formatDateTime_ISO8601(Logger::markedEpochTime)
        .toCharArray(tempBuffer, 26);
    strcat(txBuffer, "#P");
    strcat(txBuffer, "created_at=");
    strcat(txBuffer, tempBuffer);
    txBuffer[strlen(txBuffer)] = '&';

    for (uint8_t i = 0; i < numChannels; i++) {
        strcat(txBuffer, "field");
        itoa(i + 1, tempBuffer, 10);  // BASE 10
        strcat(txBuffer, tempBuffer);
        txBuffer[strlen(txBuffer)] = '=';
        _baseLogger->getValueStringAtI(i).toCharArray(tempBuffer, 26);
        strcat(txBuffer, tempBuffer);
        if (i + 1 != numChannels) { txBuffer[strlen(txBuffer)] = '&'; }
    }
    //strcat(txBuffer, "&status=MQTTPUBLISH");
    MS_DBG(F("Message ["), strlen(txBuffer), F("]:"), String(txBuffer));

    // Set the client connection parameters
    _mqttClient.setClient(*outClient);
    _mqttClient.setServer(mqttServer, mqttPort);

    // Make sure any previous TCP connections are closed
    // NOTE:  The PubSubClient library used for MQTT connect assumes that as
    // long as the client is connected, it must be connected to the right place.
    // Closing any stray client sockets here ensures that a new client socket
    // is opened to the right place.
    // client is connected when a different socket is open
    if (outClient->connected()) { outClient->stop(); }

    // Make the MQTT connection
    // Note:  the client id and the user name do not mean anything for
    // ThingSpeak
    MS_DBG(F("Opening MQTT Connection"));
    MS_START_DEBUG_TIMER;
    // Zgeneral
    // Changed to rely on ClientID, username, and password
    if (_mqttClient.connect(_influxClientID, _influxUsername, _influxPassword)) {
        MS_DBG(F("MQTT connected after"), MS_PRINT_DEBUG_TIMER, F("ms"));

        if (_mqttClient.publish(topicBuffer, txBuffer)) {
            PRINTOUT(F("Influx DB topic published!  Current state:"),
                     parseMQTTState(_mqttClient.state()));
            retVal = true;
        } else {
            PRINTOUT(F("MQTT publish failed with state:"),
                     parseMQTTState(_mqttClient.state()));
            retVal = false;
        }
    } else {
        PRINTOUT(F("MQTT connection failed with state:"),
                 parseMQTTState(_mqttClient.state()));
        delay(1000);
        retVal = false;
    }

    // Disconnect from MQTT
    MS_DBG(F("Disconnecting from MQTT"));
    MS_RESET_DEBUG_TIMER
    _mqttClient.disconnect();
    MS_DBG(F("Disconnected after"), MS_PRINT_DEBUG_TIMER, F("ms"));
    return retVal;
}
